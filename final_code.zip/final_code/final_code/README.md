# LangGraph Supervisor Agent with Flask

This project is a multi-agent data analysis and report generation system built using LangGraph and Flask. It consists of several interconnected agents to handle SQL query generation, data visualization, and report creation. The project includes the following main components:

## 📁 Project Structure

```
.
├── app.py                     # Main Flask server for handling API requests
├── requirements.txt          # Python dependencies for the project
├── agent/
│   ├── initiate_llm.py       # Initialization for LLM endpoints (GPT and LLaMA)
│   ├── final_supervisor_agent_report.py  # Main supervisor graph handling agent interactions
│   ├── sql_react_agent_llama.py  # SQL agent for generating and correcting SQL queries
│   ├── report_agent.py       # Agent for generating detailed reports with image analysis
│   └── viz_agent_memory.py   # Agent for generating data visualizations
├── static/
│   └── images/               # Stores generated visualizations
├── templates/
│   ├── chat.html             # Main frontend for chat interactions
│   └── dashboard.html        # Dashboard for viewing generated visualizations
├── reports/
│   └── (Generated PDF Reports)
└── README.md                 # This README file
```

## 📝 Project Components

### 1. `app.py`

* Main Flask server handling API requests and routing.
* Invokes the main supervisor agent (`SQL_ORCHESTRATOR`).
* Handles visualization image saving and report generation.

### 2. `requirements.txt`

* Lists all the required Python packages, including LangChain, Pandas, SQLAlchemy, Flask, and Plotly.

### 3. `agent/`

* **initiate\_llm.py**: Sets up LLM endpoints for GPT and LLaMA.
* **final\_supervisor\_agent\_report.py**: Main supervisor graph handling the end-to-end workflow of SQL, table creation, visualization, and report generation.
* **sql\_react\_agent\_llama.py**: Agent responsible for SQL generation and correction, using a structured chain to handle SQL parsing and error correction.
* **report\_agent.py**: Generates PDF reports with context-aware image analysis using the `image_llm` model.
* **viz\_agent\_memory.py**: Generates Plotly visualizations based on DataFrame descriptions and user prompts.

### 4. `static/`

* Contains generated image files for data visualizations.

### 5. `templates/`

* HTML files for the frontend UI, including the main chat interface (`chat.html`) and the dashboard (`dashboard.html`).

### 6. `reports/`

* Directory for storing generated PDF reports.

### 7. `.env` File

* Create a `.env` file in the root directory with the following content to provide your OpenAI API key for GPT-4 access:

```
OPENAI_API_KEY=your_openai_api_key_here
```

### 🚀 Getting Started

### Prerequisites

* Python 3.10+
* PostgreSQL database with a preconfigured schema (`analytical_schema`)
* Access to AzureML LLM endpoints for LLaMA (adjust endpoints in `initiate_llm.py` if required)

### Installation

```bash

# Create a virtual environment
$ python -m venv venv
$ source venv/bin/activate  # On Windows, use `venv\Scripts\activate`

# Install dependencies
$ pip install -r requirements.txt
```

### Database Configuration

* Make sure your PostgreSQL database is running.
* Replace the `setup_database()` function in `agent/sql_react_agent_llama.py` with your own local PostgreSQL connection settings to match your setup.
* Example configuration:

```python
# Replace the setup_database function with your local configuration
import sqlalchemy
from langchain_community.utilities import SQLDatabase

def setup_database():
    user = "your_username"
    psswd = "your_password"
    host = "localhost"
    port = "5432"
    db = "your_database"

    url = f"postgresql://{user}:{psswd}@{host}:{port}/{db}"
    engine = sqlalchemy.create_engine(url)
    try:
        db = SQLDatabase(engine, schema="analytical_schema")
        return db
    except Exception as e:
        raise ConnectionError(f"Failed to establish database connection: {str(e)}")
```

### Running the Application

```bash
# Start the Flask server
$ python app.py
```

### Accessing the Application

* Chat interface: [http://localhost:5000/](http://localhost:5000/)
* Dashboard: [http://localhost:5000/dashboard](http://localhost:5000/dashboard)
* Reports: [http://localhost:5000/reports](http://localhost:5000/reports)

## 📜 Generating Reports

* Reports are saved in the `reports/` directory as PDF files.
* Use the chat interface to trigger report generation by mentioning keywords like "generate a report" or "export this as PDF".

## 🛠️ Troubleshooting

* Ensure your database connection is correctly configured.
* Verify your AzureML endpoints are active and accessible.

## 📄 License

This project is licensed under the MIT License.

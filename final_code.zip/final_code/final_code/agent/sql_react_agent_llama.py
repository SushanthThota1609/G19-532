DOMAIN_KNOWLEDGE = {
    "domain_name": "HR Analytics",
    
    "code_mappings": {
        "employee_type_codes": {
            "INT": "Intern",
            "FT": "Full-Time Employee", 
            "CON": "Contractor",
            "TMP": "Temporary",
            "PT20": "Part time 20 hours",
            "PT30": "Part Time 30 hours"
        },
        
        "employee_status_codes": {
            "A": "Active",
            "T": "Terminated", 
            "L": "Long Leave"
        }
    },
    
    "business_rules": {
        "turnover_rate": {
            "formula": "Number of Terminations in Period / Average Workforce During That Period",
            "description": "CORRECT Formula - NEVER use hires as denominator, NEVER add terminations to denominator, NEVER use formulas like: terminations / (hires + terminations)"
        },
        
        "average_headcount": {
            "time_series_data": "Use AVG() function on employment flags or status indicators",
            "snapshot_data": "Count employees active during the specific time period",
            "rule": "Match the time period exactly with the metric being calculated"
        },
        
        "time_period_matching": {
            "rule": "When calculating rates (turnover, hiring, etc.), ensure numerator and denominator use the same time period",
            "extraction": "Extract years/months consistently: EXTRACT(YEAR FROM date_column) or DATE_TRUNC()",
            "current_calculations": "For 'current' calculations, use employees active as of CURRENT_DATE"
        },
        
        "required_turnover_structure": {
            "template": """
            WITH terminations AS (
              SELECT period, COUNT(DISTINCT employee_id) AS num_terminations
              FROM table WHERE termination_condition
              GROUP BY period
            ),
            average_workforce AS (
              SELECT period, calculation_for_average_workforce AS avg_workforce  
              FROM table WHERE workforce_condition
              GROUP BY period
            )
            SELECT t.period, 
                   ROUND(t.num_terminations / a.avg_workforce, 4) AS turnover_rate
            FROM terminations t
            JOIN average_workforce a ON t.period = a.period
            """
        },
        
        "data_structure_considerations": [
            "If table has HR_EMPLOYED_FLAG: Use AVG(HR_EMPLOYED_FLAG) for average headcount",
            "If table has employment dates: Count employees active during period using date ranges",
            "If table has status codes: Filter by active status codes for workforce calculation"
        ],
        
        "calculation_guidelines": [
            "Are you calculating rates correctly (appropriate numerator/denominator)?",
            "Do time periods match between numerator and denominator?", 
            "Are you using the right columns for the calculation type?",
            "Are you avoiding the forbidden calculation patterns listed above?",
            "Does the query logic make business sense?",
            "For turnover: Is denominator the workforce size (not hire count)?"
        ],
        
        "common_errors_to_avoid": [
            "Using COUNT of hires as workforce size",
            "Mixing hire year with termination year in calculations", 
            "Using formulas like: terminations / (hires + terminations)",
            "Not matching time periods between rate components",
            "Counting employees by wrong date field for workforce calculations",
            "Using hire counts instead of workforce counts in denominators"
        ]
    },
    
    "date_functions": {
        "current_date": "CURRENT_DATE",
        "extract_year": "EXTRACT(YEAR FROM column_name)",
        "date_arithmetic": "Standard SQL date functions"
    },
    
    "domain_specific_instructions": [
        "Always consider all the columns of the chosen table",
        "For time-series tables (with daily/monthly records): Use AVG(HR_EMPLOYED_FLAG) to get average headcount",
        "For snapshot tables (one record per employee): Count employees who were active during the period",
        "Always ensure termination period matches workforce calculation period",
        "NEVER count employees by their hire year when calculating workforce for termination years"
    ]
}

# =============================================================================
# PROMPT TEMPLATE BUILDER - NO NEED TO EDIT BELOW THIS LINE
# =============================================================================

def build_domain_knowledge_section(domain_config):
    """Build the domain knowledge section of the prompt from configuration."""
    
    sections = []
    
    # Domain name
    sections.append(f"Domain: {domain_config['domain_name']}")
    
    # Code mappings
    if "code_mappings" in domain_config:
        sections.append("\nDomain Knowledge / Code Mappings:")
        sections.append("When interpreting the user's intent, the following internal codes must be used:")
        
        for mapping_type, mappings in domain_config["code_mappings"].items():
            sections.append(f"\n- {mapping_type.replace('_', ' ').title()}:")
            for code, description in mappings.items():
                sections.append(f'  - "{code}" = {description}')
    
    # Business rules
    if "business_rules" in domain_config:
        rules = domain_config["business_rules"]
        
        sections.append("\nCRITICAL BUSINESS CALCULATIONS:")
        
        # Handle specific business rules
        counter = 1
        for rule_name, rule_details in rules.items():
            if rule_name == "turnover_rate":
                sections.append(f"\n{counter}. **Turnover Rate Calculation:**")
                sections.append(f"   - CORRECT Formula: {rule_details['formula']}")
                sections.append(f"   - {rule_details['description']}")
                counter += 1
            elif rule_name == "average_headcount":
                sections.append(f"\n{counter}. **Average Headcount Calculation:**")
                sections.append(f"   - For time-series data: {rule_details['time_series_data']}")
                sections.append(f"   - For snapshot data: {rule_details['snapshot_data']}")
                sections.append(f"   - {rule_details['rule']}")
                counter += 1
            elif rule_name == "time_period_matching":
                sections.append(f"\n{counter}. **Time Period Matching:**")
                sections.append(f"   - {rule_details['rule']}")
                sections.append(f"   - {rule_details['extraction']}")
                sections.append(f"   - {rule_details['current_calculations']}")
                counter += 1
            elif rule_name == "required_turnover_structure":
                sections.append(f"\n{counter}. **Required Query Structure for Turnover Rate:**")
                sections.append(f"   ```sql{rule_details['template']}   ```")
                counter += 1
            elif rule_name == "data_structure_considerations":
                sections.append(f"\n{counter}. **Data Structure Considerations:**")
                for consideration in rule_details:
                    sections.append(f"   - {consideration}")
                counter += 1
        
        # Validation checklist
        if "calculation_guidelines" in rules:
            sections.append("\nQUERY VALIDATION CHECKLIST:")
            sections.append("Before generating the final query, verify:")
            for i, guideline in enumerate(rules["calculation_guidelines"], 1):
                sections.append(f"{i}. {guideline}")
        
        # Common errors
        if "common_errors_to_avoid" in rules:
            sections.append("\nCOMMON CALCULATION ERRORS TO AVOID:")
            for error in rules["common_errors_to_avoid"]:
                sections.append(f"- {error}")
    
    # Domain-specific instructions
    if "domain_specific_instructions" in domain_config:
        sections.append("\nDomain-Specific Guidelines:")
        for instruction in domain_config["domain_specific_instructions"]:
            sections.append(f"- {instruction}")
    
    return "\n".join(sections)

# Build the domain knowledge section
DOMAIN_KNOWLEDGE_TEXT = build_domain_knowledge_section(DOMAIN_KNOWLEDGE)

# =============================================================================
# MAIN APPLICATION CODE
# =============================================================================

from dotenv import load_dotenv, find_dotenv
load_dotenv(override=True)
from langchain_community.utilities import SQLDatabase
import sqlalchemy
from langchain_community.agent_toolkits import SQLDatabaseToolkit
from langchain_core.tools import tool
from langgraph.prebuilt import create_react_agent
from langchain_core.messages import BaseMessage, HumanMessage
from langchain.chains import create_sql_query_chain
from langchain_community.tools import QuerySQLDatabaseTool
from operator import itemgetter
import re
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough, RunnableLambda

from langchain.tools import tool
from pydantic import BaseModel
from langchain.output_parsers import ResponseSchema, StructuredOutputParser

from typing import TypedDict, Annotated, Sequence
import json, ast

from langchain_core.messages import BaseMessage, HumanMessage, ToolMessage
from langgraph.graph.message import add_messages
from langgraph.graph import StateGraph, END
from langgraph.types import Command
from typing_extensions import Literal

from agent.initiate_llm import llama_llm, gpt_llm, supervisor_llm
import pandas as pd

from sqlalchemy import create_engine
from sqlalchemy.exc import SQLAlchemyError
from langchain_community.utilities.sql_database import SQLDatabase
import urllib.parse

import os
import urllib

class AgentState(TypedDict):
    messages: Annotated[Sequence[BaseMessage], add_messages]

def setup_snowflake_connection():
    """Establish Snowflake database connection using SQLAlchemy."""
    USER = "DQP"
    PASSWORD = "password"
    ACCOUNT = "GCTQLVN-YBC70425"
    WAREHOUSE = "COMPUTE_WH"
    DATABASE = "DQP"
    SCHEMA = "PUBLIC"

    if not PASSWORD:
        raise ValueError("Snowflake password not found")

    try:
        # SQLAlchemy format for Snowflake:
        connection_string = (
            f"snowflake://{USER}:{urllib.parse.quote(PASSWORD)}@{ACCOUNT}/"
            f"{DATABASE}/{SCHEMA}?warehouse={WAREHOUSE}"
        )

        engine = create_engine(connection_string)
        db = SQLDatabase(engine, schema=SCHEMA)
        return db

    except SQLAlchemyError as e:
        raise ConnectionError(f"Failed to connect to Snowflake: {str(e)}")

# Initialize the database
db = setup_snowflake_connection()

# SQL VALIDATION FUNCTION - CRITICAL SECURITY COMPONENT
def validate_sql_query(query: str) -> tuple[bool, str]:
    """
    Validate that the SQL query only contains SELECT operations.
    Returns (is_valid, error_message)
    """
    # Clean the query - remove comments and extra whitespace
    cleaned_query = re.sub(r'--.*$', '', query, flags=re.MULTILINE)  # Remove single-line comments
    cleaned_query = re.sub(r'/\*.*?\*/', '', cleaned_query, flags=re.DOTALL)  # Remove multi-line comments
    cleaned_query = cleaned_query.strip().upper()
    
    # List of prohibited operations
    prohibited_operations = [
        'INSERT', 'UPDATE', 'DELETE', 'DROP', 'CREATE', 'ALTER', 
        'TRUNCATE', 'MERGE', 'REPLACE', 'GRANT', 'REVOKE',
        'COMMIT', 'ROLLBACK', 'SAVEPOINT', 'SET', 'USE',
        'CALL', 'EXEC', 'EXECUTE', 'BULK', 'COPY'
    ]
    
    # Check for prohibited operations
    for operation in prohibited_operations:
        # Use word boundaries to avoid false positives
        if re.search(rf'\b{operation}\b', cleaned_query):
            return False, f"Operation '{operation}' is not allowed. Only SELECT queries are permitted."
    
    # Check if query starts with SELECT (after cleaning)
    if not cleaned_query.startswith('SELECT') and not cleaned_query.startswith('WITH'):
        return False, "Only SELECT queries (including CTEs with WITH) are allowed."
    
    # Additional check for semicolon-separated statements
    statements = [stmt.strip() for stmt in cleaned_query.split(';') if stmt.strip()]
    for stmt in statements:
        if stmt and not (stmt.startswith('SELECT') or stmt.startswith('WITH')):
            return False, "Multiple statements detected. Only single SELECT queries are allowed."
    
    return True, ""

# 1a) tell LangChain "I want exactly one field called query"
response_schemas = [
    ResponseSchema(name="query", description="The final corrected SQL query in backticks.")
]

# 1b) build a parser that will enforce that shape
output_parser = StructuredOutputParser.from_response_schemas(
    response_schemas
)

# UPDATED SQL TEMPLATE WITH DOMAIN CONFIGURATION
sql_chain_template = f"""
You are a Snowflake expert. Given an input question, create a syntactically correct Snowflake query to run, then look at the results of the query and return the answer to the input question.

CRITICAL SECURITY CONSTRAINT: You can ONLY generate SELECT queries. Do not use INSERT, UPDATE, DELETE, DROP, CREATE, ALTER, TRUNCATE, MERGE, or any other data modification operations. If the user asks for data modification, politely decline and explain that you can only retrieve data.

{{top_k}}. You can order the results to return the most informative data in the database.
Never query for all columns from a table. You must query only the columns that are needed to answer the question. Wrap each column name in double quotes (") to denote them as delimited identifiers.
Pay attention to use only the column names you can see in the tables below. Be careful to not query for columns that do not exist. Also, pay attention to which column is in which table.
For the given tables and their schemas, think about the question and what tables need to be used/joined in order to answer the question. Include only SELECT statements, don't let it use any other data manipulation queries.
Do not limit yourself to only one table if the question requires columns from multiple tables, think about which tables should be joined.
Pay attention to use CURRENT_DATE function to get the current date, if the question involves "today".

{DOMAIN_KNOWLEDGE_TEXT}

Only use the following tables:
{{table_info}}
=====

Question: {{input}}

Use the following format for the output:
"""

format_inst = output_parser.get_format_instructions().replace("{", "{{").replace("}", "}}")
sql_chain_template += "\n\n" + format_inst

# Create the PromptTemplate object
custom_sql_prompt = PromptTemplate(
    input_variables=["input", "table_info", "top_k"],
    template=sql_chain_template
)

# ENHANCED SQL CORRECTION TEMPLATE WITH SECURITY
sql_correction_template = f"""
You are a Snowflake expert.  
An earlier attempt at answering the user's question failed.  

IMPORTANT SECURITY CONSTRAINT: You can ONLY generate SELECT queries. Do not use INSERT, UPDATE, DELETE, DROP, CREATE, ALTER, or any other data modification operations.

User Question:
{{question}}

Previous SQL:
{{query}}

Error message:
{{error}}

Table schema:
{{table_info}}

{DOMAIN_KNOWLEDGE_TEXT}

Based on the error, you may need to join other tables or fix column names.  
Please use the following output format and ensure your query is a SELECT statement only:

"""

sql_correction_template += "\n\n" + format_inst

correction_prompt = PromptTemplate(
    input_variables=["question", "query", "error", "table_info"],
    template=sql_correction_template
)

correction_prompt = correction_prompt.partial(
    table_info=db.get_table_info(),
)

def extract_sql_block(text):
    match = re.search(r"```(?:sql|SQL|SQLQuery|mysql|postgresql)?\s*(.*?)\s*```", text, re.DOTALL)
    return match.group(1).strip() if match else ""

def clean_sql_query(text: str) -> str:
    """
    Clean SQL query by removing code block syntax, various SQL tags, backticks,
    prefixes, and unnecessary whitespace while preserving the core SQL query.
    """
    # Step 1: Remove code block syntax and any SQL-related tags
    block_pattern = r"```(?:sql|SQL|SQLQuery|mysql|postgresql)?\s*(.*?)\s*```"
    text = re.sub(block_pattern, r"\1", text, flags=re.DOTALL)

    # Step 2: Handle "SQLQuery:" prefix and similar variations
    prefix_pattern = r"^(?:SQL\s*Query|SQLQuery|MySQL|PostgreSQL|SQL)\s*:\s*"
    text = re.sub(prefix_pattern, "", text, flags=re.IGNORECASE)

    # Step 3: Extract the first SQL statement if there's random text after it
    sql_statement_pattern = r"(SELECT.*?;)"
    sql_match = re.search(sql_statement_pattern, text, flags=re.IGNORECASE | re.DOTALL)
    if sql_match:
        text = sql_match.group(1)

    # Step 4: Remove backticks around identifiers
    text = re.sub(r'`([^`]*)`', r'\1', text)

    # Step 5: Normalize whitespace
    text = re.sub(r'\s+', ' ', text)

    # Step 6: Preserve newlines for main SQL keywords to maintain readability
    keywords = ['SELECT', 'FROM', 'WHERE', 'GROUP BY', 'HAVING', 'ORDER BY',
               'LIMIT', 'JOIN', 'LEFT JOIN', 'RIGHT JOIN', 'INNER JOIN',
               'OUTER JOIN', 'UNION', 'VALUES']

    # Case-insensitive replacement for keywords (removed INSERT, UPDATE, DELETE)
    pattern = '|'.join(r'\b{}\b'.format(k) for k in keywords)
    text = re.sub(f'({pattern})', r'\n\1', text, flags=re.IGNORECASE)

    # Step 7: Final cleanup
    text = text.strip()
    text = re.sub(r'\n\s*\n', '\n', text)

    return text

class SQLToolSchema(BaseModel):
    question: str

# SECURE EXECUTE FUNCTION WITH VALIDATION
def execute_sql_query(query: str) -> str:
    """Execute SQL query against the database with security validation."""
    
    # First validate the query for security
    is_valid, error_message = validate_sql_query(query)
    if not is_valid:
        return f"Error: {error_message} Please rephrase your question to only request data retrieval."
    
    execute_query = QuerySQLDatabaseTool(db=db)
    try:
        result = execute_query.run(query)

        if isinstance(result, str):
            try:
                import ast
                return ast.literal_eval(result)
            except Exception:
                return result
        return result

    except Exception as e:
        error_msg = f"Error executing query: {str(e)}"
        return error_msg

def nl2sql_chain():
    """Tool to Generate and Execute SQL Query to answer questions."""
    print("INSIDE NL2SQL TOOL")

    # Step 1: SQL generation chain
    write_query = create_sql_query_chain(llama_llm, db, prompt=custom_sql_prompt)

    # Step 2: Build the full runnable chain
    chain = (
        RunnablePassthrough.assign(
            query=write_query | RunnableLambda(lambda raw: output_parser.parse(raw)["query"])
        )
    )

    return chain

sql_chain = nl2sql_chain()
correction_chain = correction_prompt | llama_llm | output_parser

# ENHANCED GEN_SQL_NODE WITH SECURITY VALIDATION
def gen_sql_node(state: AgentState):
    last_msg = state["messages"][-1]
    question = last_msg.content
    
    # Check if the question is asking for data modification
    modification_keywords = ['insert', 'update', 'delete', 'drop', 'create', 'alter', 'modify', 'change', 'remove', 'add new', 'truncate']
    question_lower = question.lower()
    
    for keyword in modification_keywords:
        if keyword in question_lower:
            error_response = {
                "question": question,
                "query": "",
                "result": "Error: I can only retrieve data using SELECT queries. I cannot insert, update, delete, or modify data in the database. Please rephrase your question to request data retrieval instead."
            }
            return {
                "messages": [
                    ToolMessage(
                        content=json.dumps(error_response),
                        name="nl2sql_tool",
                        tool_call_id="tool_123"
                    )
                ]
            }
    
    # Generate SQL query
    response_dict = sql_chain.invoke({"question": question})
    
    # Validate the generated query
    generated_query = response_dict.get('query', '')
    is_valid, error_message = validate_sql_query(generated_query)
    
    if not is_valid:
        error_response = {
            "question": question,
            "query": generated_query,
            "result": f"Error: {error_message} The generated query violates security constraints."
        }
        return {
            "messages": [
                ToolMessage(
                    content=json.dumps(error_response),
                    name="nl2sql_tool",
                    tool_call_id="tool_123"
                )
            ]
        }

    return {
        "messages": [
            ToolMessage(
                content=json.dumps(response_dict),
                name="nl2sql_tool",
                tool_call_id="tool_123"
            )
        ]
    }

def exec_sql_node(state: AgentState):
    last = state["messages"][-1]
    data = json.loads(last.content)
    sql_query = data['query']
    result = execute_sql_query(sql_query)

    updated_state = {
        "question": data["question"],
        "query": sql_query,
        "result": result
    }

    return {
        "messages": [
            ToolMessage(
                content=json.dumps(updated_state),
                name="exec_sql",
                tool_call_id="tool_456"
            )
        ]
    }

# ENHANCED CHECK_NODE WITH SECURITY VALIDATION
def check_node(state: AgentState) -> Command[Literal["exec_sql","__end__"]]:
    last = state["messages"][-1]
    data = json.loads(last.content)
    result = data["result"]

    # Check if this is a security validation error (don't try to correct these)
    if isinstance(result, str) and any(phrase in result.lower() for phrase in ["not allowed", "security constraints", "only select queries"]):
        # Don't try to correct security violations, just end
        return Command(goto=END)

    # if there's an error, ask the correction_chain to fix it
    if isinstance(result, str) and result.startswith("Error:"):
        correction = correction_chain.invoke({
            "question": data["question"],
            "query": data["query"],
            "error": result.split("'\n")[0]
        })

        # Validate the corrected query
        corrected_query = correction.get('query', '')
        is_valid, error_message = validate_sql_query(corrected_query)
        
        if not is_valid:
            # If correction also violates constraints, end the process
            final_error = {
                "question": data["question"],
                "query": corrected_query,
                "result": f"Error: {error_message} Unable to generate a valid SELECT query for this request."
            }
            return Command(
                update={"messages":[
                    ToolMessage(
                        content=json.dumps(final_error),
                        name="validation_error",
                        tool_call_id="tool_error"
                    )
                ]},
                goto=END
            )

        updated_state = {
            "question": data["question"],
            "query": correction['query'],
        }
        
        # emit the corrected SQL message and go re-run exec_sql
        return Command(
            update={"messages":[
                ToolMessage(
                    content=json.dumps(updated_state),
                    name="correct_sql",
                    tool_call_id="tool_789"
                )
            ]},
            goto="exec_sql"
        )

    # otherwise we're done
    return Command(goto=END)

# BUILD THE SECURE GRAPH
builder = StateGraph(AgentState)
builder.add_node("gen_sql", gen_sql_node)
builder.add_edge("gen_sql","exec_sql")
builder.add_node("exec_sql", exec_sql_node)
builder.add_edge("exec_sql","check")
builder.add_node("check", check_node)
builder.set_entry_point("gen_sql")
graph = builder.compile(name="secure_sql_agent")

#### Tool for making dataframe
def make_dataframe(query: str, result):
    """Convert SQL query result to a Pandas DataFrame."""
    df_schema = pd.read_sql(query, db._engine)
    return df_schema

# TESTING THE SECURE AGENT - Following the working pattern from your code
print("=== Testing Safe Query ===")
initial_state = { "messages": [HumanMessage(content="Give me the names of 5 employees along with their full time or part time status")] }
final_state = graph.invoke(initial_state)
print(final_state)

print("\n=== Testing Prohibited Query ===")
prohibited_state = { "messages": [HumanMessage(content="Delete all employees from the employee table")] }
prohibited_result = graph.invoke(prohibited_state)
print(prohibited_result)

print("\n=== Testing Another Prohibited Query ===")
update_state = { "messages": [HumanMessage(content="Update employee salaries to increase by 10%")] }
update_result = graph.invoke(update_state)
print(update_result)

# Make the secure agent available
SQL_SUBAGENT = graph

# Test dataframe creation with safe query - Creating df at module level like your working code
temp = [['Hispanic or Latino', 81], ['Native American', 57], ['Asian', 67], ['White', 74], [None, 144]]
query = '''
SELECT "ETHNICDESCRIPTION", COUNT("EMPLOYEEID")
FROM PUBLIC.DIM_UKG_EMPLOYEE_DEMOGRAPHIC_DETAILS
GROUP BY "ETHNICDESCRIPTION"
LIMIT 5
'''
df = make_dataframe(query, temp)
print("\n=== DataFrame Creation Test ===")
print(df)


# from dotenv import load_dotenv, find_dotenv
# load_dotenv(override=True)
# from langchain_community.utilities import SQLDatabase
# import sqlalchemy
# from langchain_community.agent_toolkits import SQLDatabaseToolkit
# from langchain_core.tools import tool
# from langgraph.prebuilt import create_react_agent
# from langchain_core.messages import BaseMessage, HumanMessage
# from langchain.chains import create_sql_query_chain
# from langchain_community.tools import QuerySQLDatabaseTool
# from operator import itemgetter
# import re
# from langchain_core.prompts import PromptTemplate
# from langchain_core.output_parsers import StrOutputParser
# from langchain_core.runnables import RunnablePassthrough, RunnableLambda

# from langchain.tools import tool
# from pydantic import BaseModel
# from langchain.output_parsers import ResponseSchema, StructuredOutputParser

# from typing import TypedDict, Annotated, Sequence
# import json, ast

# from langchain_core.messages import BaseMessage, HumanMessage, ToolMessage
# from langgraph.graph.message import add_messages
# from langgraph.graph import StateGraph, END
# from langgraph.types import Command
# from typing_extensions import Literal

# from agent.initiate_llm import llama_llm, gpt_llm, supervisor_llm
# import pandas as pd

# from sqlalchemy import create_engine
# from sqlalchemy.exc import SQLAlchemyError
# from langchain_community.utilities.sql_database import SQLDatabase
# import urllib.parse

# import os
# import urllib

# class AgentState(TypedDict):
#     messages: Annotated[Sequence[BaseMessage], add_messages]

# def setup_snowflake_connection():
#     """Establish Snowflake database connection using SQLAlchemy."""
#     USER = "DQP"
#     PASSWORD = "Dqp_Project_12$"
#     ACCOUNT = "GCTQLVN-YBC70425"
#     WAREHOUSE = "COMPUTE_WH"
#     DATABASE = "DQP"
#     SCHEMA = "PUBLIC"

#     if not PASSWORD:
#         raise ValueError("Snowflake password not found")

#     try:
#         # SQLAlchemy format for Snowflake:
#         connection_string = (
#             f"snowflake://{USER}:{urllib.parse.quote(PASSWORD)}@{ACCOUNT}/"
#             f"{DATABASE}/{SCHEMA}?warehouse={WAREHOUSE}"
#         )

#         engine = create_engine(connection_string)
#         db = SQLDatabase(engine, schema=SCHEMA)
#         return db

#     except SQLAlchemyError as e:
#         raise ConnectionError(f"Failed to connect to Snowflake: {str(e)}")

# # Initialize the database
# db = setup_snowflake_connection()

# # SQL VALIDATION FUNCTION - CRITICAL SECURITY COMPONENT
# def validate_sql_query(query: str) -> tuple[bool, str]:
#     """
#     Validate that the SQL query only contains SELECT operations.
#     Returns (is_valid, error_message)
#     """
#     # Clean the query - remove comments and extra whitespace
#     cleaned_query = re.sub(r'--.*$', '', query, flags=re.MULTILINE)  # Remove single-line comments
#     cleaned_query = re.sub(r'/\*.*?\*/', '', cleaned_query, flags=re.DOTALL)  # Remove multi-line comments
#     cleaned_query = cleaned_query.strip().upper()
    
#     # List of prohibited operations
#     prohibited_operations = [
#         'INSERT', 'UPDATE', 'DELETE', 'DROP', 'CREATE', 'ALTER', 
#         'TRUNCATE', 'MERGE', 'REPLACE', 'GRANT', 'REVOKE',
#         'COMMIT', 'ROLLBACK', 'SAVEPOINT', 'SET', 'USE',
#         'CALL', 'EXEC', 'EXECUTE', 'BULK', 'COPY'
#     ]
    
#     # Check for prohibited operations
#     for operation in prohibited_operations:
#         # Use word boundaries to avoid false positives
#         if re.search(rf'\b{operation}\b', cleaned_query):
#             return False, f"Operation '{operation}' is not allowed. Only SELECT queries are permitted."
    
#     # Check if query starts with SELECT (after cleaning)
#     if not cleaned_query.startswith('SELECT') and not cleaned_query.startswith('WITH'):
#         return False, "Only SELECT queries (including CTEs with WITH) are allowed."
    
#     # Additional check for semicolon-separated statements
#     statements = [stmt.strip() for stmt in cleaned_query.split(';') if stmt.strip()]
#     for stmt in statements:
#         if stmt and not (stmt.startswith('SELECT') or stmt.startswith('WITH')):
#             return False, "Multiple statements detected. Only single SELECT queries are allowed."
    
#     return True, ""

# # 1a) tell LangChain "I want exactly one field called query"
# response_schemas = [
#     ResponseSchema(name="query", description="The final corrected SQL query in backticks.")
# ]

# # 1b) build a parser that will enforce that shape
# output_parser = StructuredOutputParser.from_response_schemas(
#     response_schemas
# )

# sql_chain_template = """
# You are a Snowflake expert. Given an input question, create a syntactically correct Snowflake query to run, then look at the results of the query and return the answer to the input question.

# CRITICAL SECURITY CONSTRAINT: You can ONLY generate SELECT queries. Do not use INSERT, UPDATE, DELETE, DROP, CREATE, ALTER, TRUNCATE, MERGE, or any other data modification operations. If the user asks for data modification, politely decline and explain that you can only retrieve data.

# {top_k}. You can order the results to return the most informative data in the database.
# Never query for all columns from a table. You must query only the columns that are needed to answer the question. Wrap each column name in double quotes (") to denote them as delimited identifiers.
# Pay attention to use only the column names you can see in the tables below. Be careful to not query for columns that do not exist. Also, pay attention to which column is in which table.
# For the given tables and their schemas, think about the question and what tables need to be used/joined in order to answer the question. Include only SELECT statements, don't let it use any other data manipulation queries.
# Do not limit yourself to only one table if the question requires columns from multiple tables, think about which tables should be joined.
# Pay attention to use CURRENT_DATE function to get the current date, if the question involves "today".

# Domain Knowledge / Code Mappings:

#     When interpreting the user's intent, the following internal codes must be used:

#     - Employee Type Codes:
#         - "INT" = Intern
#         - "FT" = Full-Time Employee
#         - "CON" = Contractor
#         - "TMP" = Temporary
#         - "PT20" = Part time 20 hours
#         - "PT30" = Part Time 30 hours
        
# Employee Status Code Mapping:

#     When interpreting the user's intent, the following status codes must be used:

#   - Always use the following rules when translating status codes:
#     - "A" → 'Active'
#     - "T" → 'Terminated'
#     - "L" → 'Long Leave'

# CRITICAL BUSINESS CALCULATIONS:

# 1. **Turnover Rate Calculation:**
#    - CORRECT Formula: Turnover Rate = Number of Terminations in Period / Average Workforce During That Period
#    - NEVER use hires as denominator
#    - NEVER add terminations to denominator  
#    - NEVER use formulas like: terminations / (hires + terminations)
#    - For time-series tables (with daily/monthly records): Use AVG(employed_flag) to get average headcount
#    - For snapshot tables (one record per employee): Count employees who were active during the period
#    - Always ensure termination period matches workforce calculation period

# 2. **Average Headcount Calculation:**
#    - For time-series data: Use AVG() function on employment flags or status indicators
#    - For snapshot data: Count employees active during the specific time period  
#    - Match the time period exactly with the metric being calculated
#    - NEVER count employees by their hire year when calculating workforce for termination years

# 3. **Time Period Matching:**
#    - When calculating rates (turnover, hiring, etc.), ensure numerator and denominator use the same time period
#    - Extract years/months consistently: EXTRACT(YEAR FROM date_column) or DATE_TRUNC()
#    - For "current" calculations, use employees active as of CURRENT_DATE

# 4. **Required Query Structure for Turnover Rate:**
#    ```sql
#    WITH terminations AS (
#      SELECT period, COUNT(DISTINCT employee_id) AS num_terminations
#      FROM table WHERE termination_condition
#      GROUP BY period
#    ),
#    average_workforce AS (
#      SELECT period, calculation_for_average_workforce AS avg_workforce  
#      FROM table WHERE workforce_condition
#      GROUP BY period
#    )
#    SELECT t.period, 
#           ROUND(t.num_terminations / a.avg_workforce, 4) AS turnover_rate
#    FROM terminations t
#    JOIN average_workforce a ON t.period = a.period
#    ```

# 5. **Data Structure Considerations:**
#    - If table has HR_EMPLOYED_FLAG: Use AVG(HR_EMPLOYED_FLAG) for average headcount
#    - If table has employment dates: Count employees active during period using date ranges
#    - If table has status codes: Filter by active status codes for workforce calculation

# QUERY VALIDATION CHECKLIST:
# Before generating the final query, verify:
# 1. Are you calculating rates correctly (appropriate numerator/denominator)?
# 2. Do time periods match between numerator and denominator?
# 3. Are you using the right columns for the calculation type?
# 4. Are you avoiding the forbidden calculation patterns listed above?
# 5. Does the query logic make business sense?
# 6. For turnover: Is denominator the workforce size (not hire count)?

# COMMON CALCULATION ERRORS TO AVOID:
# - Using COUNT of hires as workforce size
# - Mixing hire year with termination year in calculations
# - Using formulas like: terminations / (hires + terminations)  
# - Not matching time periods between rate components
# - Counting employees by wrong date field for workforce calculations
# - Using hire counts instead of workforce counts in denominators

# Only use the following tables:
# {table_info}
# =====

# Question: {input}

# Use the following format for the output:
# """

# format_inst = output_parser.get_format_instructions().replace("{", "{{").replace("}", "}}")
# sql_chain_template += "\n\n" + format_inst

# # Create the PromptTemplate object
# custom_sql_prompt = PromptTemplate(
#     input_variables=["input", "table_info", "top_k"],
#     template=sql_chain_template
# )

# # # ENHANCED SQL TEMPLATE WITH SECURITY CONSTRAINTS
# # sql_chain_template = """
# # You are a Snowflake expert. Given an input question, create a syntactically correct Snowflake query to run, then look at the results of the query and return the answer to the input question.

# # CRITICAL SECURITY CONSTRAINT: You can ONLY generate SELECT queries. Do not use INSERT, UPDATE, DELETE, DROP, CREATE, ALTER, TRUNCATE, MERGE, or any other data modification operations. If the user asks for data modification, politely decline and explain that you can only retrieve data.

# # {top_k}. You can order the results to return the most informative data in the database.
# # Never query for all columns from a table. You must query only the columns that are needed to answer the question. Wrap each column name in double quotes (") to denote them as delimited identifiers.
# # Pay attention to use only the column names you can see in the tables below. Be careful to not query for columns that do not exist. Also, pay attention to which column is in which table.
# # For the given tables and their schemas, think about the question and what tables need to be used/joined in order to answer the question. Include only SELECT statements, don't let it use any other data manipulation queries.
# # Do not limit yourself to only one table if the question requires columns from multiple tables, think about which tables should be joined.
# # Pay attention to use CURRENT_DATE function to get the current date, if the question involves "today".

# # Domain Knowledge / Code Mappings:

# #     When interpreting the user's intent, the following internal codes must be used:

# #     - Employee Type Codes:
# #         - "INT" = Intern
# #         - "FT" = Full-Time Employee
# #         - "CON" = Contractor
# #         - "TMP" = Temporary
# #         -"PT20" = Part time 20 hours
# #         -"PT30" = Part Time 30 hours
        
# # Employee Status Code Mapping:

# #     When interpreting the user's intent, the following status codes must be used:

# #   - Always use the following rules when translating status codes:
# #     - "A" → 'Active'
# #     - "T" → 'Terminated'
# #     - "L" → 'Long Leave'

# # Business Calculations:
# # Always consider all the columns of the chosen table.
# #     - Turnover Rate Calculation:
# #         Use this formula for turnover calculations: Turnover Rate = Terminations in Period / Average Workforce During That Period

# # Only use the following tables:
# # {table_info}
# # =====

# # Question: {input}

# # Use the following format for the output:
# # """

# # format_inst = output_parser.get_format_instructions().replace("{", "{{").replace("}", "}}")
# # sql_chain_template += "\n\n" + format_inst

# # # Create the PromptTemplate object
# # custom_sql_prompt = PromptTemplate(
# #     input_variables=["input", "table_info", "top_k"],
# #     template=sql_chain_template
# # )

# # ENHANCED SQL CORRECTION TEMPLATE WITH SECURITY
# sql_correction_template = """
# You are a Snowflake expert.  
# An earlier attempt at answering the user's question failed.  

# IMPORTANT SECURITY CONSTRAINT: You can ONLY generate SELECT queries. Do not use INSERT, UPDATE, DELETE, DROP, CREATE, ALTER, or any other data modification operations.

# User Question:
# {question}

# Previous SQL:
# {query}

# Error message:
# {error}

# Table schema:
# {table_info}

# Based on the error, you may need to join other tables or fix column names.  
# Please use the following output format and ensure your query is a SELECT statement only:

# """

# sql_correction_template += "\n\n" + format_inst

# correction_prompt = PromptTemplate(
#     input_variables=["question", "query", "error", "table_info"],
#     template=sql_correction_template
# )

# correction_prompt = correction_prompt.partial(
#     table_info=db.get_table_info(),
# )

# def extract_sql_block(text):
#     match = re.search(r"```(?:sql|SQL|SQLQuery|mysql|postgresql)?\s*(.*?)\s*```", text, re.DOTALL)
#     return match.group(1).strip() if match else ""

# def clean_sql_query(text: str) -> str:
#     """
#     Clean SQL query by removing code block syntax, various SQL tags, backticks,
#     prefixes, and unnecessary whitespace while preserving the core SQL query.
#     """
#     # Step 1: Remove code block syntax and any SQL-related tags
#     block_pattern = r"```(?:sql|SQL|SQLQuery|mysql|postgresql)?\s*(.*?)\s*```"
#     text = re.sub(block_pattern, r"\1", text, flags=re.DOTALL)

#     # Step 2: Handle "SQLQuery:" prefix and similar variations
#     prefix_pattern = r"^(?:SQL\s*Query|SQLQuery|MySQL|PostgreSQL|SQL)\s*:\s*"
#     text = re.sub(prefix_pattern, "", text, flags=re.IGNORECASE)

#     # Step 3: Extract the first SQL statement if there's random text after it
#     sql_statement_pattern = r"(SELECT.*?;)"
#     sql_match = re.search(sql_statement_pattern, text, flags=re.IGNORECASE | re.DOTALL)
#     if sql_match:
#         text = sql_match.group(1)

#     # Step 4: Remove backticks around identifiers
#     text = re.sub(r'`([^`]*)`', r'\1', text)

#     # Step 5: Normalize whitespace
#     text = re.sub(r'\s+', ' ', text)

#     # Step 6: Preserve newlines for main SQL keywords to maintain readability
#     keywords = ['SELECT', 'FROM', 'WHERE', 'GROUP BY', 'HAVING', 'ORDER BY',
#                'LIMIT', 'JOIN', 'LEFT JOIN', 'RIGHT JOIN', 'INNER JOIN',
#                'OUTER JOIN', 'UNION', 'VALUES']

#     # Case-insensitive replacement for keywords (removed INSERT, UPDATE, DELETE)
#     pattern = '|'.join(r'\b{}\b'.format(k) for k in keywords)
#     text = re.sub(f'({pattern})', r'\n\1', text, flags=re.IGNORECASE)

#     # Step 7: Final cleanup
#     text = text.strip()
#     text = re.sub(r'\n\s*\n', '\n', text)

#     return text

# class SQLToolSchema(BaseModel):
#     question: str

# # SECURE EXECUTE FUNCTION WITH VALIDATION
# def execute_sql_query(query: str) -> str:
#     """Execute SQL query against the database with security validation."""
    
#     # First validate the query for security
#     is_valid, error_message = validate_sql_query(query)
#     if not is_valid:
#         return f"Error: {error_message} Please rephrase your question to only request data retrieval."
    
#     execute_query = QuerySQLDatabaseTool(db=db)
#     try:
#         result = execute_query.run(query)

#         if isinstance(result, str):
#             try:
#                 import ast
#                 return ast.literal_eval(result)
#             except Exception:
#                 return result
#         return result

#     except Exception as e:
#         error_msg = f"Error executing query: {str(e)}"
#         return error_msg

# def nl2sql_chain():
#     """Tool to Generate and Execute SQL Query to answer questions."""
#     print("INSIDE NL2SQL TOOL")

#     # Step 1: SQL generation chain
#     write_query = create_sql_query_chain(llama_llm, db, prompt=custom_sql_prompt)

#     # Step 2: Build the full runnable chain
#     chain = (
#         RunnablePassthrough.assign(
#             query=write_query | RunnableLambda(lambda raw: output_parser.parse(raw)["query"])
#         )
#     )

#     return chain

# sql_chain = nl2sql_chain()
# correction_chain = correction_prompt | llama_llm | output_parser

# # ENHANCED GEN_SQL_NODE WITH SECURITY VALIDATION
# def gen_sql_node(state: AgentState):
#     last_msg = state["messages"][-1]
#     question = last_msg.content
    
#     # Check if the question is asking for data modification
#     modification_keywords = ['insert', 'update', 'delete', 'drop', 'create', 'alter', 'modify', 'change', 'remove', 'add new', 'truncate']
#     question_lower = question.lower()
    
#     for keyword in modification_keywords:
#         if keyword in question_lower:
#             error_response = {
#                 "question": question,
#                 "query": "",
#                 "result": "Error: I can only retrieve data using SELECT queries. I cannot insert, update, delete, or modify data in the database. Please rephrase your question to request data retrieval instead."
#             }
#             return {
#                 "messages": [
#                     ToolMessage(
#                         content=json.dumps(error_response),
#                         name="nl2sql_tool",
#                         tool_call_id="tool_123"
#                     )
#                 ]
#             }
    
#     # Generate SQL query
#     response_dict = sql_chain.invoke({"question": question})
    
#     # Validate the generated query
#     generated_query = response_dict.get('query', '')
#     is_valid, error_message = validate_sql_query(generated_query)
    
#     if not is_valid:
#         error_response = {
#             "question": question,
#             "query": generated_query,
#             "result": f"Error: {error_message} The generated query violates security constraints."
#         }
#         return {
#             "messages": [
#                 ToolMessage(
#                     content=json.dumps(error_response),
#                     name="nl2sql_tool",
#                     tool_call_id="tool_123"
#                 )
#             ]
#         }

#     return {
#         "messages": [
#             ToolMessage(
#                 content=json.dumps(response_dict),
#                 name="nl2sql_tool",
#                 tool_call_id="tool_123"
#             )
#         ]
#     }

# def exec_sql_node(state: AgentState):
#     last = state["messages"][-1]
#     data = json.loads(last.content)
#     sql_query = data['query']
#     result = execute_sql_query(sql_query)

#     updated_state = {
#         "question": data["question"],
#         "query": sql_query,
#         "result": result
#     }

#     return {
#         "messages": [
#             ToolMessage(
#                 content=json.dumps(updated_state),
#                 name="exec_sql",
#                 tool_call_id="tool_456"
#             )
#         ]
#     }

# # ENHANCED CHECK_NODE WITH SECURITY VALIDATION
# def check_node(state: AgentState) -> Command[Literal["exec_sql","__end__"]]:
#     last = state["messages"][-1]
#     data = json.loads(last.content)
#     result = data["result"]

#     # Check if this is a security validation error (don't try to correct these)
#     if isinstance(result, str) and any(phrase in result.lower() for phrase in ["not allowed", "security constraints", "only select queries"]):
#         # Don't try to correct security violations, just end
#         return Command(goto=END)

#     # if there's an error, ask the correction_chain to fix it
#     if isinstance(result, str) and result.startswith("Error:"):
#         correction = correction_chain.invoke({
#             "question": data["question"],
#             "query": data["query"],
#             "error": result.split("'\n")[0]
#         })

#         # Validate the corrected query
#         corrected_query = correction.get('query', '')
#         is_valid, error_message = validate_sql_query(corrected_query)
        
#         if not is_valid:
#             # If correction also violates constraints, end the process
#             final_error = {
#                 "question": data["question"],
#                 "query": corrected_query,
#                 "result": f"Error: {error_message} Unable to generate a valid SELECT query for this request."
#             }
#             return Command(
#                 update={"messages":[
#                     ToolMessage(
#                         content=json.dumps(final_error),
#                         name="validation_error",
#                         tool_call_id="tool_error"
#                     )
#                 ]},
#                 goto=END
#             )

#         updated_state = {
#             "question": data["question"],
#             "query": correction['query'],
#         }
        
#         # emit the corrected SQL message and go re-run exec_sql
#         return Command(
#             update={"messages":[
#                 ToolMessage(
#                     content=json.dumps(updated_state),
#                     name="correct_sql",
#                     tool_call_id="tool_789"
#                 )
#             ]},
#             goto="exec_sql"
#         )

#     # otherwise we're done
#     return Command(goto=END)

# # BUILD THE SECURE GRAPH
# builder = StateGraph(AgentState)
# builder.add_node("gen_sql", gen_sql_node)
# builder.add_edge("gen_sql","exec_sql")
# builder.add_node("exec_sql", exec_sql_node)
# builder.add_edge("exec_sql","check")
# builder.add_node("check", check_node)
# builder.set_entry_point("gen_sql")
# graph = builder.compile(name="secure_sql_agent")

# #### Tool for making dataframe
# def make_dataframe(query: str, result):
#     """Convert SQL query result to a Pandas DataFrame."""
#     df_schema = pd.read_sql(query, db._engine)
#     return df_schema

# # TESTING THE SECURE AGENT
# print("=== Testing Safe Query ===")
# initial_state = { "messages": [HumanMessage(content="Give me the names of 5 employees along with their full time or part time status")] }
# final_state = graph.invoke(initial_state)
# print(final_state)

# print("\n=== Testing Prohibited Query ===")
# prohibited_state = { "messages": [HumanMessage(content="Delete all employees from the employee table")] }
# prohibited_result = graph.invoke(prohibited_state)
# print(prohibited_result)

# print("\n=== Testing Another Prohibited Query ===")
# update_state = { "messages": [HumanMessage(content="Update employee salaries to increase by 10%")] }
# update_result = graph.invoke(update_state)
# print(update_result)

# # Make the secure agent available
# SQL_SUBAGENT = graph

# # Test dataframe creation with safe query
# temp = [['Hispanic or Latino', 81], ['Native American', 57], ['Asian', 67], ['White', 74], [None, 144]]
# query = '''
# SELECT "ETHNICDESCRIPTION", COUNT("EMPLOYEEID")
# FROM PUBLIC.DIM_UKG_EMPLOYEE_DEMOGRAPHIC_DETAILS
# GROUP BY "ETHNICDESCRIPTION"
# LIMIT 5
# '''
# df = make_dataframe(query, temp)
# print("\n=== DataFrame Creation Test ===")
# print(df)

# =============================================================================
# DOMAIN CONFIGURATION - EDIT THIS SECTION FOR DIFFERENT DOMAINS
# =============================================================================



# =============================================================================
# USAGE EXAMPLE: How to adapt for different domains
# =============================================================================

# """
# To use this for a different domain, simply update the DOMAIN_KNOWLEDGE dictionary:

# DOMAIN_KNOWLEDGE = {
#     "domain_name": "Financial Analytics",
    
#     "code_mappings": {
#         "account_types": {
#             "CHK": "Checking Account",
#             "SAV": "Savings Account", 
#             "CD": "Certificate of Deposit"
#         },
        
#         "transaction_codes": {
#             "D": "Debit",
#             "C": "Credit",
#             "P": "Pending"
#         }
#     },
    
#     "business_rules": {
#         "roi_calculation": {
#             "formula": "(Gain - Cost) / Cost * 100",
#             "description": "Return on Investment calculation"
#         },
        
#         "calculation_guidelines": [
#             "Are financial periods properly aligned?",
#             "Are you using correct accounting principles?",
#             "Do calculations follow regulatory requirements?"
#         ],
        
#         "common_errors_to_avoid": [
#             "Not considering currency exchange rates",
#             "Mixing different accounting periods",
#             "Ignoring regulatory compliance requirements"
#         ]
#     },
    
#     "domain_specific_instructions": [
#         "Always consider fiscal year vs calendar year",
#         "Handle currency conversions appropriately",
#         "Consider time value of money in calculations"
#     ]
# }
# """


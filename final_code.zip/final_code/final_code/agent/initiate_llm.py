from dotenv import load_dotenv
from langchain_community.chat_models.azureml_endpoint import AzureMLChatOnlineEndpoint, AzureMLEndpointApiType, CustomOpenAIChatContentFormatter
load_dotenv(override=True)
from langchain_core.messages import HumanMessage
from langchain_openai import ChatOpenAI
from langchain_core.messages import BaseMessage
from openai import OpenAI

llama_llm =  AzureMLChatOnlineEndpoint(
    endpoint_url="https://Meta-Llama-3-1-70B-Instruct-zhlk.westus.models.ai.azure.com/chat/completions",
    endpoint_api_type=AzureMLEndpointApiType.serverless,
    endpoint_api_key="ap_key",
    content_formatter=CustomOpenAIChatContentFormatter(),
    model_kwargs={"temperature": 0.3, "max_tokens": 2000}
)

supervisor_llm = ChatOpenAI(model="gpt-3.5-turbo", temperature=0.2,api_key="api_key")
gpt_llm = ChatOpenAI(model="gpt-4o", temperature=0.7, api_key="api_key")
image_llm = OpenAI(api_key="api_key")
